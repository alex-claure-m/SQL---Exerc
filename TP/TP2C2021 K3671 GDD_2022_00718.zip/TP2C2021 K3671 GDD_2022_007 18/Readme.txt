Curso: K3671
Numero de grupo: 18
Nombre y legajo de todos los integrantes:
Claure Montecinos, Alexander Maximiliano 150541-5
De Vergilio, Juan Ignacio 135520-0
Hanashiro, Leonardo Martin 163876-2
Mollon, Rodrigo Javier 162821-5
Email del integrante responsable del grupo: mollonr@frba.utn.edu.ar